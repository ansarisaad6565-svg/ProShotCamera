# ProShot Camera
CameraX based camera: max-resolution JPEG, HQ noise reduction/edge mode, Night/HDR/Portrait (device extensions),
DSLR-look post processing, tap-to-focus, pinch zoom, EV slider and a Document scanner (JPEG + PDF).

Build: push to GitHub -> Actions tab -> "Build APK" -> download artifact ProShotCamera-APK.
