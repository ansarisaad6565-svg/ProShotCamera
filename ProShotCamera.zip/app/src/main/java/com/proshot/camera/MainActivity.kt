package com.proshot.camera

import android.Manifest
import android.content.ContentValues
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.hardware.camera2.CaptureRequest
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.camera2.interop.Camera2Interop
import androidx.camera.camera2.interop.ExperimentalCamera2Interop
import androidx.camera.core.AspectRatio
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.FocusMeteringAction
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.core.resolutionselector.AspectRatioStrategy
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.extensions.ExtensionMode
import androidx.camera.extensions.ExtensionsManager
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.documentscanner.GmsDocumentScannerOptions
import com.google.mlkit.vision.documentscanner.GmsDocumentScanning
import com.google.mlkit.vision.documentscanner.GmsDocumentScanningResult
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

class MainActivity : AppCompatActivity() {

    enum class Mode(val label: String) {
        PHOTO("PHOTO"), PORTRAIT("PORTRAIT"), NIGHT("NIGHT"), HDR("HDR"), DOC("DOCUMENT")
    }

    private lateinit var previewView: PreviewView
    private lateinit var evBar: SeekBar
    private lateinit var flashBtn: TextView
    private lateinit var dslrBtn: TextView
    private val modeViews = mutableMapOf<Mode, TextView>()

    private var provider: ProcessCameraProvider? = null
    private var extMgr: ExtensionsManager? = null
    private var camera: Camera? = null
    private var imageCapture: ImageCapture? = null

    private var lensFacing = CameraSelector.LENS_FACING_BACK
    private var mode = Mode.PHOTO
    private var flashMode = ImageCapture.FLASH_MODE_OFF
    private var dslrBoost = true
    private var evLower = 0
    private var useSoft = false
    @Volatile private var busy = false

    private val executor = Executors.newSingleThreadExecutor()

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
            if (ok) startCamera() else toast("Camera permission chahiye")
        }

    private val scanLauncher =
        registerForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { r ->
            if (r.resultCode == RESULT_OK) {
                val res = GmsDocumentScanningResult.fromActivityResultIntent(r.data)
                val stamp = stamp()
                res?.pages?.forEachIndexed { i, p ->
                    copyToStore(p.imageUri, MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                        "DOC_${stamp}_${i + 1}.jpg", "image/jpeg", "Pictures/ProShot Docs")
                }
                res?.pdf?.let {
                    copyToStore(it.uri, MediaStore.Downloads.EXTERNAL_CONTENT_URI,
                        "DOC_$stamp.pdf", "application/pdf", "Download/ProShot Docs")
                }
                toast("Document save ho gaya (PDF: Downloads/ProShot Docs)")
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        buildUi()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
            == PackageManager.PERMISSION_GRANTED) startCamera()
        else permLauncher.launch(Manifest.permission.CAMERA)
    }

    // ---------------- UI ----------------
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun label(text: String, size: Float = 14f) = TextView(this).apply {
        this.text = text
        setTextColor(Color.WHITE)
        textSize = size
        setPadding(dp(14), dp(10), dp(14), dp(10))
    }

    private fun buildUi() {
        val root = FrameLayout(this).apply {
            setBackgroundColor(Color.BLACK)
            fitsSystemWindows = true
        }
        previewView = PreviewView(this).apply { scaleType = PreviewView.ScaleType.FIT_CENTER }
        root.addView(previewView, FrameLayout.LayoutParams(-1, -1))

        // gestures: pinch zoom + tap focus
        val scale = ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(d: ScaleGestureDetector): Boolean {
                val cam = camera ?: return true
                val z = cam.cameraInfo.zoomState.value?.zoomRatio ?: 1f
                cam.cameraControl.setZoomRatio(z * d.scaleFactor)
                return true
            }
        })
        val tap = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onSingleTapUp(e: MotionEvent): Boolean {
                val cam = camera ?: return true
                val pt = previewView.meteringPointFactory.createPoint(e.x, e.y)
                cam.cameraControl.startFocusAndMetering(FocusMeteringAction.Builder(pt).build())
                return true
            }
        })
        previewView.setOnTouchListener { v, ev ->
            scale.onTouchEvent(ev); tap.onTouchEvent(ev)
            if (ev.action == MotionEvent.ACTION_UP) v.performClick()
            true
        }

        // top bar
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        flashBtn = label("FLASH: OFF").apply { setOnClickListener { cycleFlash() } }
        dslrBtn = label("DSLR: ON").apply { setOnClickListener { toggleDslr() } }
        val flip = label("FLIP").apply { setOnClickListener { flipCamera() } }
        top.addView(flashBtn); top.addView(dslrBtn); top.addView(flip)
        root.addView(top, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.CENTER_HORIZONTAL))

        // bottom stack
        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(0, 0, 0, dp(16))
        }
        evBar = SeekBar(this).apply {
            visibility = View.INVISIBLE
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    if (fromUser) camera?.cameraControl?.setExposureCompensationIndex(p + evLower)
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        bottom.addView(evBar, LinearLayout.LayoutParams(dp(260), -2))

        val strip = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        Mode.values().forEach { m ->
            val tv = label(m.label, 13f).apply { setOnClickListener { selectMode(m) } }
            modeViews[m] = tv
            strip.addView(tv)
        }
        val scroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            addView(strip)
        }
        bottom.addView(scroll, LinearLayout.LayoutParams(-2, -2))

        val shutter = View(this).apply {
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.WHITE)
                setStroke(dp(5), Color.parseColor("#888888"))
            }
            setOnClickListener { onShutter() }
        }
        bottom.addView(shutter, LinearLayout.LayoutParams(dp(76), dp(76)).apply { topMargin = dp(12) })
        root.addView(bottom, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))

        setContentView(root)
        highlightMode()
    }

    private fun highlightMode() {
        modeViews.forEach { (m, tv) ->
            tv.setTextColor(if (m == mode) Color.parseColor("#FFD54F") else Color.WHITE)
        }
    }

    private fun selectMode(m: Mode) {
        mode = m
        highlightMode()
        if (m != Mode.DOC) bindCamera()
    }

    private fun cycleFlash() {
        flashMode = when (flashMode) {
            ImageCapture.FLASH_MODE_OFF -> ImageCapture.FLASH_MODE_AUTO
            ImageCapture.FLASH_MODE_AUTO -> ImageCapture.FLASH_MODE_ON
            else -> ImageCapture.FLASH_MODE_OFF
        }
        imageCapture?.flashMode = flashMode
        flashBtn.text = "FLASH: " + when (flashMode) {
            ImageCapture.FLASH_MODE_AUTO -> "AUTO"
            ImageCapture.FLASH_MODE_ON -> "ON"
            else -> "OFF"
        }
    }

    private fun toggleDslr() {
        dslrBoost = !dslrBoost
        dslrBtn.text = "DSLR: " + if (dslrBoost) "ON" else "OFF"
    }

    private fun flipCamera() {
        lensFacing = if (lensFacing == CameraSelector.LENS_FACING_BACK)
            CameraSelector.LENS_FACING_FRONT else CameraSelector.LENS_FACING_BACK
        bindCamera()
    }

    // ---------------- Camera ----------------
    private fun startCamera() {
        val f = ProcessCameraProvider.getInstance(this)
        f.addListener({
            provider = f.get()
            val ef = ExtensionsManager.getInstanceAsync(this, provider!!)
            ef.addListener({
                extMgr = ef.get()
                bindCamera()
            }, ContextCompat.getMainExecutor(this))
        }, ContextCompat.getMainExecutor(this))
    }

    @androidx.annotation.OptIn(ExperimentalCamera2Interop::class)
    private fun bindCamera() {
        val p = provider ?: return
        p.unbindAll()

        var selector = CameraSelector.Builder().requireLensFacing(lensFacing).build()
        val extMode = when (mode) {
            Mode.PORTRAIT -> ExtensionMode.BOKEH
            Mode.NIGHT -> ExtensionMode.NIGHT
            Mode.HDR -> ExtensionMode.HDR
            else -> ExtensionMode.NONE
        }
        useSoft = false
        var extApplied = false
        if (extMode != ExtensionMode.NONE) {
            val em = extMgr
            if (em != null && em.isExtensionAvailable(selector, extMode)) {
                selector = em.getExtensionEnabledCameraSelector(selector, extMode)
                extApplied = true
            } else {
                useSoft = true
                toast("Phone ka vendor ${mode.label} app ko nahi deta - app ka apna software ${mode.label} chalega")
            }
        }

        val preview = Preview.Builder()
            .setResolutionSelector(
                ResolutionSelector.Builder()
                    .setAspectRatioStrategy(AspectRatioStrategy.RATIO_4_3_FALLBACK_AUTO_STRATEGY)
                    .build()
            ).build()
        preview.setSurfaceProvider(previewView.surfaceProvider)

        val icb = ImageCapture.Builder()
            .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
            .setJpegQuality(100)
            .setFlashMode(flashMode)
            .setResolutionSelector(
                ResolutionSelector.Builder()
                    .setAspectRatioStrategy(AspectRatioStrategy.RATIO_4_3_FALLBACK_AUTO_STRATEGY)
                    .setResolutionStrategy(ResolutionStrategy.HIGHEST_AVAILABLE_STRATEGY)
                    .build()
            )
        if (!extApplied) {
            // ask the ISP for its best noise-reduction and edge-enhancement
            Camera2Interop.Extender(icb)
                .setCaptureRequestOption(CaptureRequest.NOISE_REDUCTION_MODE,
                    CaptureRequest.NOISE_REDUCTION_MODE_HIGH_QUALITY)
                .setCaptureRequestOption(CaptureRequest.EDGE_MODE,
                    CaptureRequest.EDGE_MODE_HIGH_QUALITY)
        }
        imageCapture = icb.build()

        try {
            camera = p.bindToLifecycle(this, selector, preview, imageCapture)
            val range = camera!!.cameraInfo.exposureState.exposureCompensationRange
            evLower = range.lower
            if (range.upper > range.lower) {
                evBar.max = range.upper - range.lower
                evBar.progress = -range.lower
                evBar.visibility = View.VISIBLE
            } else evBar.visibility = View.INVISIBLE
        } catch (e: Exception) {
            toast("Camera start nahi hua: ${e.message}")
        }
    }

    private fun onShutter() {
        if (mode == Mode.DOC) { openScanner(); return }
        if (busy) { toast("Processing chal rahi hai, ruko..."); return }
        if (useSoft && (mode == Mode.HDR || mode == Mode.NIGHT || mode == Mode.PORTRAIT)) {
            softCapture(); return
        }
        val ic = imageCapture ?: return
        val file = File(cacheDir, "cap_${System.currentTimeMillis()}.jpg")
        ic.takePicture(
            ImageCapture.OutputFileOptions.Builder(file).build(),
            executor,
            object : ImageCapture.OnImageSavedCallback {
                override fun onImageSaved(r: ImageCapture.OutputFileResults) {
                    var out = file
                    if (dslrBoost) {
                        out = try { DslrProcessor.enhance(file, cacheDir) }
                        catch (t: Throwable) { file }
                    }
                    copyToStore(Uri.fromFile(out), MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                        "IMG_${stamp()}.jpg", "image/jpeg", "Pictures/ProShot")
                    if (out != file) out.delete()
                    file.delete()
                    toast("Photo save ho gayi")
                }
                override fun onError(e: ImageCaptureException) {
                    toast("Capture error: ${e.message}")
                }
            })
    }

    // ---------------- Software HDR / Night / Portrait ----------------
    private fun softCapture() {
        busy = true
        toast(
            when (mode) {
                Mode.NIGHT -> "Phone ko ek dum steady pakdo (tripod best)... 6 frames le raha hoon"
                Mode.HDR -> "HDR: 3 shots le raha hoon, hilna mat..."
                else -> "Portrait: photo + background blur ban raha hai..."
            }
        )
        executor.execute {
            val frames = ArrayList<File>()
            val base = evBar.progress + evLower
            try {
                when (mode) {
                    Mode.HDR -> for (ev in floatArrayOf(-2f, 0f, 2f)) {
                        setEv(evIndexFor(ev))
                        captureSync()?.let { frames.add(it) }
                    }
                    Mode.NIGHT -> {
                        setEv(evIndexFor(2f))
                        repeat(6) { captureSync()?.let { frames.add(it) } }
                    }
                    else -> captureSync()?.let { frames.add(it) }
                }
                setEv(base)
                if (frames.isEmpty()) {
                    toast("Capture nahi hua")
                } else {
                    var out: File = try {
                        when (mode) {
                            Mode.HDR -> if (frames.size >= 2) SoftModes.hdr(frames, cacheDir) else frames[0]
                            Mode.NIGHT -> if (frames.size >= 2) SoftModes.night(frames, cacheDir) else frames[0]
                            else -> SoftModes.portrait(frames[0], cacheDir) ?: run {
                                toast("Portrait: koi insaan nahi mila, normal photo save ki")
                                frames[0]
                            }
                        }
                    } catch (t: Throwable) {
                        toast("Processing fail (${t.javaClass.simpleName}), normal frame save ki")
                        frames[frames.size / 2]
                    }
                    if (dslrBoost) {
                        out = try { DslrProcessor.enhance(out, cacheDir) } catch (t: Throwable) { out }
                    }
                    copyToStore(Uri.fromFile(out), MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                        "IMG_${stamp()}_${mode.label}.jpg", "image/jpeg", "Pictures/ProShot")
                    toast("${mode.label} photo save ho gayi")
                }
            } catch (t: Throwable) {
                toast("Error: ${t.message}")
            } finally {
                cacheDir.listFiles()?.forEach {
                    if (it.name.startsWith("soft_") || it.name.startsWith("dslr_") ||
                        it.name.startsWith("frame_")) it.delete()
                }
                busy = false
            }
        }
    }

    private fun captureSync(): File? {
        val ic = imageCapture ?: return null
        val f = File(cacheDir, "frame_${System.nanoTime()}.jpg")
        val latch = CountDownLatch(1)
        var ok = false
        runOnUiThread {
            ic.takePicture(
                ImageCapture.OutputFileOptions.Builder(f).build(),
                ContextCompat.getMainExecutor(this),
                object : ImageCapture.OnImageSavedCallback {
                    override fun onImageSaved(r: ImageCapture.OutputFileResults) {
                        ok = true
                        latch.countDown()
                    }
                    override fun onError(e: ImageCaptureException) {
                        latch.countDown()
                    }
                })
        }
        latch.await(20, TimeUnit.SECONDS)
        return if (ok) f else null
    }

    private fun setEv(idx: Int) {
        try {
            camera?.cameraControl?.setExposureCompensationIndex(idx)?.get(3, TimeUnit.SECONDS)
        } catch (_: Exception) { }
        try { Thread.sleep(600) } catch (_: InterruptedException) { }
    }

    private fun evIndexFor(ev: Float): Int {
        val st = camera?.cameraInfo?.exposureState ?: return 0
        val step = st.exposureCompensationStep.toFloat()
        val r = st.exposureCompensationRange
        if (step <= 0f) return 0
        return Math.round(ev / step).coerceIn(r.lower, r.upper)
    }

    // ---------------- Document scanner ----------------
    private fun openScanner() {
        val opts = GmsDocumentScannerOptions.Builder()
            .setGalleryImportAllowed(true)
            .setPageLimit(25)
            .setResultFormats(
                GmsDocumentScannerOptions.RESULT_FORMAT_JPEG,
                GmsDocumentScannerOptions.RESULT_FORMAT_PDF
            )
            .setScannerMode(GmsDocumentScannerOptions.SCANNER_MODE_FULL)
            .build()
        GmsDocumentScanning.getClient(opts)
            .getStartScanIntent(this)
            .addOnSuccessListener { sender ->
                scanLauncher.launch(IntentSenderRequest.Builder(sender).build())
            }
            .addOnFailureListener { toast("Scanner open nahi hua: ${it.message}") }
    }

    // ---------------- Storage helpers ----------------
    private fun stamp() = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())

    private fun copyToStore(src: Uri, collection: Uri, name: String, mime: String, relPath: String) {
        try {
            val v = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                put(MediaStore.MediaColumns.MIME_TYPE, mime)
                put(MediaStore.MediaColumns.RELATIVE_PATH, relPath)
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }
            val dst = contentResolver.insert(collection, v) ?: return
            contentResolver.openInputStream(src)!!.use { i ->
                contentResolver.openOutputStream(dst)!!.use { o -> i.copyTo(o) }
            }
            v.clear()
            v.put(MediaStore.MediaColumns.IS_PENDING, 0)
            contentResolver.update(dst, v, null, null)
        } catch (e: Exception) {
            toast("Save error: ${e.message}")
        }
    }

    private fun toast(msg: String) = runOnUiThread {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }
}
