package com.proshot.camera

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import androidx.exifinterface.media.ExifInterface
import java.io.File
import java.io.FileOutputStream

/**
 * "DSLR Look": mild unsharp-mask (detail), S-curve contrast and a little saturation.
 * Works row-by-row, in place, to keep memory low on big sensors.
 */
object DslrProcessor {

    private val lut = IntArray(256) { i ->
        // gentle S-curve around mid-grey
        val x = i / 255f
        val s = x + 0.12f * (x - 0.5f) * (1f - Math.abs(2f * x - 1f)) * 2f
        (s.coerceIn(0f, 1f) * 255f + 0.5f).toInt()
    }

    private fun tone(p: Int): Int {
        var r = lut[(p shr 16) and 255]
        var g = lut[(p shr 8) and 255]
        var b = lut[p and 255]
        val l = (299 * r + 587 * g + 114 * b) / 1000
        r = (l + (r - l) * 114 / 100).coerceIn(0, 255)
        g = (l + (g - l) * 114 / 100).coerceIn(0, 255)
        b = (l + (b - l) * 114 / 100).coerceIn(0, 255)
        return (0xFF shl 24) or (r shl 16) or (g shl 8) or b
    }

    fun enhance(src: File, cacheDir: File): File {
        val opts = BitmapFactory.Options().apply {
            inMutable = true
            inPreferredConfig = Bitmap.Config.ARGB_8888
        }
        val bmp = BitmapFactory.decodeFile(src.absolutePath, opts) ?: return src
        val w = bmp.width
        val h = bmp.height

        var prev = IntArray(w)
        var cur = IntArray(w)
        var next = IntArray(w)
        val out = IntArray(w)
        bmp.getPixels(cur, 0, w, 0, 0, w, 1)

        for (y in 0 until h) {
            if (y + 1 < h) bmp.getPixels(next, 0, w, 0, y + 1, w, 1)
            if (y == 0 || y == h - 1) {
                for (x in 0 until w) out[x] = tone(cur[x])
            } else {
                out[0] = tone(cur[0])
                out[w - 1] = tone(cur[w - 1])
                for (x in 1 until w - 1) {
                    val c = cur[x]; val u = prev[x]; val d = next[x]
                    val l = cur[x - 1]; val r = cur[x + 1]
                    val rr = sharp((c shr 16) and 255, (u shr 16) and 255, (d shr 16) and 255, (l shr 16) and 255, (r shr 16) and 255)
                    val gg = sharp((c shr 8) and 255, (u shr 8) and 255, (d shr 8) and 255, (l shr 8) and 255, (r shr 8) and 255)
                    val bb = sharp(c and 255, u and 255, d and 255, l and 255, r and 255)
                    out[x] = tone((0xFF shl 24) or (rr shl 16) or (gg shl 8) or bb)
                }
            }
            bmp.setPixels(out, 0, w, 0, y, w, 1)
            val t = prev; prev = cur; cur = next; next = t
        }

        val dst = File(cacheDir, "dslr_${System.currentTimeMillis()}.jpg")
        FileOutputStream(dst).use { bmp.compress(Bitmap.CompressFormat.JPEG, 97, it) }
        bmp.recycle()

        // copy EXIF (orientation etc.) from original
        try {
            val a = ExifInterface(src.absolutePath)
            val b = ExifInterface(dst.absolutePath)
            listOf(
                ExifInterface.TAG_ORIENTATION, ExifInterface.TAG_DATETIME, ExifInterface.TAG_MAKE,
                ExifInterface.TAG_MODEL, ExifInterface.TAG_EXPOSURE_TIME, ExifInterface.TAG_F_NUMBER,
                ExifInterface.TAG_FOCAL_LENGTH
            ).forEach { tag -> a.getAttribute(tag)?.let { b.setAttribute(tag, it) } }
            b.saveAttributes()
        } catch (_: Exception) { }
        return dst
    }

    // unsharp: out = c + 0.375 * (4c - up - down - left - right)
    private fun sharp(c: Int, u: Int, d: Int, l: Int, r: Int): Int {
        val v = c + ((4 * c - u - d - l - r) * 3 shr 3)
        return if (v < 0) 0 else if (v > 255) 255 else v
    }
}
