package com.proshot.camera

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import androidx.exifinterface.media.ExifInterface
import java.io.File
import java.io.FileOutputStream
import kotlin.math.abs
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * "Natural Pro" look. Everything works on luma/chroma separately so colours never shift:
 *  - chroma denoise (colour noise removed, detail kept)
 *  - noise-gated luma sharpening (edges only, no grain boost, no halos)
 *  - gentle local contrast (depth / "pop")
 *  - soft highlight roll-off + slight shadow lift + very mild S-curve
 *  - vibrance (boosts dull colours, leaves already-saturated colours / skin alone)
 */
object DslrProcessor {

    private fun lumaRow(px: IntArray, dst: FloatArray) {
        for (x in px.indices) {
            val p = px[x]
            dst[x] = 0.299f * ((p shr 16) and 255) + 0.587f * ((p shr 8) and 255) + 0.114f * (p and 255)
        }
    }

    fun enhance(src: File, cacheDir: File): File {
        val opts = BitmapFactory.Options().apply {
            inMutable = true
            inPreferredConfig = Bitmap.Config.ARGB_8888
        }
        val bmp = BitmapFactory.decodeFile(src.absolutePath, opts) ?: return src
        val w = bmp.width
        val h = bmp.height

        // ---- low-res (1/4) planes: big-radius luma for local contrast, blurred chroma for denoise
        val lw = max(2, w / 4)
        val lh = max(2, h / 4)
        val tiny = Bitmap.createScaledBitmap(bmp, lw, lh, true)
        val lp = IntArray(lw * lh)
        tiny.getPixels(lp, 0, lw, 0, 0, lw, lh)
        if (tiny !== bmp) tiny.recycle()
        val ly = FloatArray(lw * lh)
        val lcb = FloatArray(lw * lh)
        val lcr = FloatArray(lw * lh)
        for (i in lp.indices) {
            val p = lp[i]
            val r = ((p shr 16) and 255).toFloat()
            val g = ((p shr 8) and 255).toFloat()
            val b = (p and 255).toFloat()
            ly[i] = 0.299f * r + 0.587f * g + 0.114f * b
            lcb[i] = -0.168736f * r - 0.331264f * g + 0.5f * b
            lcr[i] = 0.5f * r - 0.418688f * g - 0.081312f * b
        }
        val ylow = SoftModes.blurF(SoftModes.blurF(ly, lw, lh, 8), lw, lh, 8)
        val cbl = SoftModes.blurF(lcb, lw, lh, 2)
        val crl = SoftModes.blurF(lcr, lw, lh, 2)

        val lx0 = IntArray(w)
        val lx1 = IntArray(w)
        val lxf = FloatArray(w)
        for (x in 0 until w) {
            val u = ((x + 0.5f) * lw / w - 0.5f).coerceIn(0f, (lw - 1).toFloat())
            val i0 = floor(u).toInt()
            lx0[x] = i0
            lx1[x] = min(i0 + 1, lw - 1)
            lxf[x] = u - i0
        }
        val rY = FloatArray(lw)
        val rCb = FloatArray(lw)
        val rCr = FloatArray(lw)

        // ---- full-res pass with rolling rows (in place)
        var rowPx = IntArray(w)
        var nextPx = IntArray(w)
        val outRow = IntArray(w)
        var yPrev = FloatArray(w)
        var yCur = FloatArray(w)
        var yNext = FloatArray(w)
        bmp.getPixels(rowPx, 0, w, 0, 0, w, 1)
        lumaRow(rowPx, yCur)
        System.arraycopy(yCur, 0, yPrev, 0, w)

        for (y in 0 until h) {
            if (y + 1 < h) {
                bmp.getPixels(nextPx, 0, w, 0, y + 1, w, 1)
                lumaRow(nextPx, yNext)
            } else {
                System.arraycopy(yCur, 0, yNext, 0, w)
            }
            val v = ((y + 0.5f) * lh / h - 0.5f).coerceIn(0f, (lh - 1).toFloat())
            val j0 = floor(v).toInt()
            val j1 = min(j0 + 1, lh - 1)
            val fy = v - j0
            for (i in 0 until lw) {
                rY[i] = ylow[j0 * lw + i] * (1f - fy) + ylow[j1 * lw + i] * fy
                rCb[i] = cbl[j0 * lw + i] * (1f - fy) + cbl[j1 * lw + i] * fy
                rCr[i] = crl[j0 * lw + i] * (1f - fy) + crl[j1 * lw + i] * fy
            }

            for (x in 0 until w) {
                val p = rowPx[x]
                val r = ((p shr 16) and 255).toFloat()
                val g = ((p shr 8) and 255).toFloat()
                val b = (p and 255).toFloat()
                val cy = yCur[x]
                val f = lxf[x]

                // sharpen: only real edges (noise gate), clamped to avoid halos
                val avg = (yCur[max(x - 1, 0)] + yCur[min(x + 1, w - 1)] + yPrev[x] + yNext[x]) * 0.25f
                val d = cy - avg
                val ad = abs(d)
                val gate = if (ad < 2f) 0f else if (ad >= 7f) 1f else (ad - 2f) / 5f
                val sharp = (d * 0.6f * gate).coerceIn(-12f, 12f)

                // local contrast
                val ylo = rY[lx0[x]] * (1f - f) + rY[lx1[x]] * f
                val local = ((cy - ylo) * 0.16f).coerceIn(-22f, 22f)

                // tone
                var xv = ((cy + sharp + local) / 255f).coerceIn(0f, 1f)
                val inv = 1f - xv
                xv += 0.035f * inv * inv * inv
                if (xv > 0.82f) xv = 0.82f + (xv - 0.82f) * 0.85f
                xv += 0.12f * (xv * xv * (3f - 2f * xv) - xv)
                val y3 = xv.coerceIn(0f, 1f) * 255f

                // chroma: denoise (more in shadows) + vibrance
                val cb0 = -0.168736f * r - 0.331264f * g + 0.5f * b
                val cr0 = 0.5f * r - 0.418688f * g - 0.081312f * b
                val a = 0.55f - 0.35f * (cy / 255f)
                var cb = cb0 + a * ((rCb[lx0[x]] * (1f - f) + rCb[lx1[x]] * f) - cb0)
                var cr = cr0 + a * ((rCr[lx0[x]] * (1f - f) + rCr[lx1[x]] * f) - cr0)
                val sat = sqrt(cb * cb + cr * cr)
                val vib = 1f + 0.12f * (1f - min(1f, sat / 70f))
                cb *= vib
                cr *= vib

                val rr = (y3 + 1.402f * cr + 0.5f).toInt().coerceIn(0, 255)
                val gg = (y3 - 0.344136f * cb - 0.714136f * cr + 0.5f).toInt().coerceIn(0, 255)
                val bb = (y3 + 1.772f * cb + 0.5f).toInt().coerceIn(0, 255)
                outRow[x] = (0xFF shl 24) or (rr shl 16) or (gg shl 8) or bb
            }
            bmp.setPixels(outRow, 0, w, 0, y, w, 1)

            val t = yPrev; yPrev = yCur; yCur = yNext; yNext = t
            val t2 = rowPx; rowPx = nextPx; nextPx = t2
        }

        val dst = File(cacheDir, "dslr_${System.currentTimeMillis()}.jpg")
        FileOutputStream(dst).use { bmp.compress(Bitmap.CompressFormat.JPEG, 97, it) }
        bmp.recycle()

        try {
            val a = ExifInterface(src.absolutePath)
            val b = ExifInterface(dst.absolutePath)
            listOf(
                ExifInterface.TAG_ORIENTATION, ExifInterface.TAG_DATETIME, ExifInterface.TAG_MAKE,
                ExifInterface.TAG_MODEL, ExifInterface.TAG_EXPOSURE_TIME, ExifInterface.TAG_F_NUMBER,
                ExifInterface.TAG_FOCAL_LENGTH
            ).forEach { tag -> a.getAttribute(tag)?.let { b.setAttribute(tag, it) } }
            b.saveAttributes()
        } catch (_: Exception) { }
        return dst
    }
}
